import 'package:flutter/material.dart';

class SEARCH extends StatelessWidget {
  const SEARCH({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SingleChildScrollView(
          child: Column(
            children: [
              SearchBar(
                hintText: "Search for titles, genres, people...",
                hintStyle: MaterialStateProperty.resolveWith((states) => TextStyle(color: Colors.grey)),
                backgroundColor: MaterialStateColor.resolveWith((states) => Color.fromARGB(201, 1, 1, 0)),
              ),
              SizedBox(height: 10),
              Container(
                height: MediaQuery.of(context).size.height * 0.05,
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.all(3),
                child: const Text(
                  "Top Searches",
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
              SizedBox(height: 10),
              Column(
                children: [
                  SearchItemRow(
                    imagePath: "assets/Dare.jpg",
                    title: "Daredevil",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/umbrella.jpg",
                    title: "The Umbrella Academy",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/extra.jpg",
                    title: "Extraordinary Attorney Woo",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/gooddoctor.jpg",
                    title: "The Good Doctor",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/lalaland.jpg",
                    title: "La La Land",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/business.jpg",
                    title: "Business Proposal",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/goodplace.jpg",
                    title: "The Good Place",
                  ),
                  SizedBox(height: 10),
                  SearchItemRow(
                    imagePath: "assets/vincenzo.jpg",
                    title: "Vincenzo",
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SearchItemRow extends StatelessWidget {
  final String imagePath;
  final String title;

  const SearchItemRow({
    required this.imagePath,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    //double itemWidth = MediaQuery.of(context).size.width; 
    double itemHeight = MediaQuery.of(context).size.height * 0.1;

    return Container(
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            height: itemHeight,
            width: itemHeight * 2, 
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 5),
            ],
          ),
          Spacer(), 
          Icon(Icons.play_circle_outline_sharp, size: 30, color: Colors.white),
        ],
      ),
    );
  }
}
