import 'package:flutter/material.dart';

class GAMES extends StatelessWidget {
  const GAMES({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          "Games",
          style: TextStyle(color: Colors.white, fontSize: 30),
        ),
        actions: [
          Icon(Icons.notifications_none_outlined),
          Padding(padding: EdgeInsets.only(left: 5)),
          Icon(Icons.account_box_outlined),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [

                Container(width: MediaQuery.of(context).size.width,
                  child: Image.asset("assets/Capture.png")),
                Positioned(
                  bottom: 50,
                  left: 50,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: Row(
                          children: [
                            Image.asset(
                              "assets/nf.png",
                              width: 15,
                              height: 15,
                            ),
                            Text(
                              "G A M E S",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w100,
                                  color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 20, right: 20),
                        child: Row(
                          children: [
                            Text(
                              "Unlimited access to exclusive games",
                              style: TextStyle(
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 20, right: 20),
                        child: Column(
                          children: [
                            Text(
                              "No ads. No extra fees. No in-app purchases.",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.white),
                            ),
                            Text(
                              "Included with your membership",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              "Recently Released",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  GameContainer(
                    imagePath: "assets/rope.jpg",
                    title: "Cut the Rope Daily",
                  ),
                  GameContainer(
                    imagePath: "assets/queen.jpg",
                    title: "The Queen's Gambit Chess",
                  ),
                  GameContainer(
                    imagePath: "assets/relic.png",
                    title: "Relic Hunters: Rebels",
                  ),
                  GameContainer(
                    imagePath: "assets/dustneon.png",
                    title: "Dust & Neon",
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Mobile Games",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  GameContainer(
                    imagePath: "assets/dead.png",
                    title: "Into the Dead 2: Unleashed",
                  ),
                  GameContainer(
                    imagePath: "assets/poinpy.png",
                    title: "Poinpy",
                  ),
                  GameContainer(
                    imagePath: "assets/tombraider.png",
                    title: "Tomb Raider Reloaded",
                  ),
                  GameContainer(
                    imagePath: "assets/raji.png",
                    title: "Raji: An Ancient Epic",
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            // Stack(
            //   children: [
            //     Image.asset("assets/ngame.PNG"),
            //     Positioned(
            //       bottom: 50,
            //       left: 50,
            //       child: Column(
            //         children: [
            //           Padding(
            //             padding: const EdgeInsets.only(left: 20, right: 20),
            //             child: Row(
            //               children: [
            //                 Text(
            //                   "Create your Netflix game handle",
            //                   style: TextStyle(
            //                       fontSize: 30,
            //                       fontWeight: FontWeight.w100,
            //                       color: Colors.grey),
            //                 ),
            //               ],
            //             ),
            //           ),
            //           Container(
            //             padding: EdgeInsets.all(20),
            //             child: Text(
            //               "Get Started",
            //               style: TextStyle(fontSize: 20),
            //             ),
            //           )
            //         ],
            //       ),
            //     ),
            //   ],
            // ),
            // SizedBox(height: 20),
            Text(
              "Mobile Games Trailers",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            GameTrailer(
              imagePath: "assets/tomb.png",
              gameImage: "assets/tombraider.png",
              title: "Tomb Raider Reloaded",
              genre: "Action",
            ),
            SizedBox(height: 10,),
            GameTrailer(
              imagePath: "assets/rajiimg.jpg",
              gameImage: "assets/raji.png",
              title: "Raji: An Ancient Epic",
              genre: "Action",
            ),
            SizedBox(height: 10,),
            GameTrailer(
              imagePath: "assets/undead.jpg",
              gameImage: "assets/dead.png",
              title: "Into the Dead 2: Unleashed",
              genre: "Action",
            ),
            SizedBox(height: 10,),
            GameTrailer(
              imagePath: "assets/pon.jpg",
              gameImage: "assets/poinpy.png",
              title: "Poinpy",
              genre: "Action",
            ),
          ],
        ),
      ),
    );
  }
}

class GameContainer extends StatelessWidget {
  final String imagePath;
  final String title;

  const GameContainer({
    required this.imagePath,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      width: 150,
      decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(20))),
      child: Column(
        children: [
          Image.asset(imagePath, height: 100,
      width: 100,),
          Text(
            title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

class GameTrailer extends StatelessWidget {
  final String imagePath;
  final String gameImage;
  final String title;
  final String genre;

  const GameTrailer({
    required this.imagePath,
    required this.gameImage,
    required this.title,
    required this.genre,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      
      child: Column(
        children: [
          Image.asset(imagePath, height: MediaQuery.of(context).size.height*0.4, width: MediaQuery.of(context).size.width*0.9,),
          SizedBox(height: 10,),
          Row(
            children: [
              SizedBox(width: 35),
              Image.asset(gameImage, width: 70, height: 70), // Adjust width and height
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(fontSize: 18,color: Colors.white ,fontWeight: FontWeight.bold),
                  ),
                  Text(
                    genre,
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ],
              ),
              
            ],
          ),
        ],
      ),
    );
  }
}

