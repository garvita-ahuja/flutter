import 'package:flutter/material.dart';

class COMINGSOON extends StatelessWidget {
  const COMINGSOON({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text(
            "New & Hot",
            style: TextStyle(color: Colors.white, fontSize: 30),
          ),
          actions: [
            Icon(Icons.notifications_none_outlined),
            Padding(padding: EdgeInsets.only(left: 5)),
            Icon(Icons.search),
            Padding(padding: EdgeInsets.only(left: 5)),
            Icon(Icons.account_box_outlined),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 50,
                child: ListView(
                  padding: const EdgeInsets.all(5),
                  scrollDirection: Axis.horizontal,
                  children: [
                    CategoryContainer(text: "Coming Soon"),
                    SizedBox(width: 5),
                    CategoryContainer(text: "Everyone's Watching"),
                    SizedBox(width: 5),
                    CategoryContainer(text: "Games"),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DateSection(day: "18", month: "AUG"),
                      SizedBox(width: 10),
                      MovieContainer(
                        imagePath: "assets/heartofstone.jpg",
                        title: "Coming on 11 August",
                        description:
                            "An intelligence operative for a shadowy global peacekeeping agency races to stop a hacker from stealing its most valuable — and dangerous — weapon.",
                        vibe: "Adrenaline Rush, Exciting, Thriller",
                        logoImagePath: "assets/heart.png",
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DateSection(day: "16", month: "AUG"),
                      SizedBox(width: 10),
                      MovieContainer(
                        imagePath: "assets/depp.jpg",
                        title: "Coming on 16 August",
                        description:
                            "Showing both testimonies side-by-side for the first time, this series explores the trial that set Hollywood ablaze and the online fallout that ensued.",
                        vibe: "Riveting, Provocative, Docuseries",
                        logoImagePath: "assets/heard.png",
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DateSection(day: "18", month: "AUG"),
                      SizedBox(width: 10),
                      MovieContainer(
                        imagePath: "assets/maskgirl.jpg",
                        title: "Coming on 18 August",
                        description:
                            "An office worker who is insecure about her looks becomes a masked internet personality by night — until a chain of ill-fated events overtakes her life.",
                        vibe: "Offbeat, Suspenseful, Thriller",
                        logoImagePath: "assets/mask.jpg",
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DateSection(day: "18", month: "AUG"),
                      SizedBox(width: 10),
                      MovieContainer(
                        imagePath: "assets/guns.jpg",
                        title: "Coming on 18 August",
                        description:
                            "In the cartel-run town of Gulaabgunj, an unprecedented opium deal pulls a big-city cop and a lovesick mechanic into its chaotic clutches.",
                        vibe: "Offbeat, Exciting, Thriller",
                        logoImagePath: "assets/gulab.png",
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class DateSection extends StatelessWidget {
  final String day;
  final String month;

  const DateSection({
    required this.day,
    required this.month,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(month, style: TextStyle(color: Colors.white)),
        SizedBox(height: 5),
        Text(day, style: TextStyle(fontSize: 40, color: Colors.white, fontWeight: FontWeight.bold)),
      ],
    );
  }
}

class MovieContainer extends StatelessWidget {
  final String imagePath;
  final String title;
  final String description;
  final String vibe;
  final String logoImagePath;

  const MovieContainer({
    required this.imagePath,
    required this.title,
    required this.description,
    required this.vibe,
    required this.logoImagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width*0.8,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Image.asset(imagePath),
          Row(
            
            children: [
              Image.asset(logoImagePath, width: 300, height: 150),
              Spacer(),
              NotificationIcon(icon: Icons.notifications_none_outlined, text: "Remind Me"),
              Spacer(),
              NotificationIcon(icon: Icons.info_outline, text: "Info"),
            ],
          ),
          SizedBox(height: 5),
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
          ),
          Text(
            description,
            style: TextStyle(color: Colors.white),
          ),
          Text(
            vibe,
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class NotificationIcon extends StatelessWidget {
  final IconData icon;
  final String text;

  const NotificationIcon({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.white),
        SizedBox(height: 2),
        Text(text, style: TextStyle(fontSize: 12, color: Colors.white)),
      ],
    );
  }
}

class CategoryContainer extends StatelessWidget {
  final String text;

  const CategoryContainer({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 200,
      
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.white,),
      child: Center(
        child: Text(
          text,
          style: TextStyle(color: Colors.black),
        ),
      ),
    );
  }
}


