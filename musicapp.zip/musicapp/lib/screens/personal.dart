import 'package:flutter/material.dart';

class PERSONAL extends StatefulWidget {
  const PERSONAL({super.key});

  @override
  State<PERSONAL> createState() => _PERSONALState();
}

class _PERSONALState extends State<PERSONAL> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: const Icon(Icons.notifications),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [const Chip(label: Text("MUSIC")), SizedBox(width: MediaQuery.of(context).size.width*0.1), const Chip(label: Text("PODCASTS"))],),
        actions: const [Icon(Icons.settings)],
        centerTitle: true,
        
      ),
      body:  Column(children: [
        const Padding(
          padding: EdgeInsets.all(8.0),
          child: ListTile(title: Text("Playlist", style: TextStyle( color: Colors.white,),), trailing: Icon(Icons.arrow_forward_ios, color: Colors.white,), tileColor: Colors.grey,),
        ),
        const Padding(
          padding: EdgeInsets.all(8.0),
          child: ListTile(title: Text("Album",style: TextStyle( color: Colors.white,),), trailing: Icon(Icons.arrow_forward_ios, color: Colors.white,), tileColor: Colors.grey,),
        ),
        const Padding(
          padding: EdgeInsets.all(8.0),
          child: ListTile(title: Text("Songs",style: TextStyle( color: Colors.white,),), trailing: Icon(Icons.arrow_forward_ios, color: Colors.white,), tileColor: Colors.grey,),
        ),
        const Padding(
          padding: EdgeInsets.all(8.0),
          child: Center(child: Text("Recents")),
        ),
        ListTile(
      leading: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          image: const DecorationImage(
            image: NetworkImage("https://imagesvc.meredithcorp.io/v3/mm/image?url=https://static.onecms.io/wp-content/uploads/sites/6/2017/11/taylor-swift-reputation.jpg"),
            fit: BoxFit.cover,
          ),
        ),
      ),
      title: const Text(
        "Recently Added Songs",
        style: TextStyle( color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '10 songs',
        style: TextStyle(
          fontSize: 14,
          color: Colors.grey,
        ),
      ),
      ),
      ListTile(
      leading: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          image: const DecorationImage(
            image: NetworkImage("https://imagesvc.meredithcorp.io/v3/mm/image?url=https://static.onecms.io/wp-content/uploads/sites/6/2017/11/taylor-swift-reputation.jpg"),
            fit: BoxFit.cover,
          ),
        ),
      ),
      title: const Text(
        "Recently Added Songs",
        style: TextStyle( color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '10 songs',
        style: TextStyle(
          fontSize: 14,
          color: Colors.grey,
        ),
      ),
      ),
      ListTile(
      leading: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          image: const DecorationImage(
            image: NetworkImage("https://imagesvc.meredithcorp.io/v3/mm/image?url=https://static.onecms.io/wp-content/uploads/sites/6/2017/11/taylor-swift-reputation.jpg"),
            fit: BoxFit.cover,
          ),
        ),
      ),
      title: const Text(
        "Recently Added Songs",
        style: TextStyle( color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      subtitle: const Text(
        '10 songs',
        style: TextStyle(
          fontSize: 14,
          color: Colors.grey,
        ),
      ),
      )
      
      ],)));
  }
}