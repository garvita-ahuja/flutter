import 'package:flutter/material.dart';
import 'package:notes/screens/loginPage.dart';
import 'package:notes/services/userauth.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final GlobalKey<FormFieldState> _formKey = GlobalKey();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  UserAuth firebaseAuth = UserAuth();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        TextFormField(
                          decoration: InputDecoration(labelText: "First Name"),
                          controller: firstNameController,
                        ),
                        TextFormField(
                          decoration: InputDecoration(labelText: "Last Name"),
                          controller: lastNameController,
                        ),
                        TextFormField(
                          decoration: InputDecoration(labelText: "Phone Number"),
                          controller: phoneNumberController,
                          validator: (phone) {
                            if (phone!.length != 10) {
                              return "Please enter a valid phone number";
                            }
                            return null;
                          },
                        ),
                        TextFormField(
                          decoration: InputDecoration(labelText: "Email Address"),
                          controller: emailController,
                        ),
                        TextFormField(
                          obscureText: true,
                          decoration: InputDecoration(labelText: "Password"),
                          controller: passwordController,
                        ),
                        SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () async {
                            String userEmail = await firebaseAuth.registerUser(
                              firstName: firstNameController.text,
                              lastName: lastNameController.text,
                              phoneNumber: phoneNumberController.text,
                              registerEmail: emailController.text,
                              registerPassword: passwordController.text,
                            );
                            print("User registered: $userEmail");
                          },
                          child: const Text("Register Now"),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const LoginPage()),
                            );
                          },
                          child: const Text("Already have an account? Login here"),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
