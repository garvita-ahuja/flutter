import 'package:flutter/material.dart';
import 'package:netflix/screens/comingsoon.dart';
import 'package:netflix/screens/homePage.dart';
import 'package:netflix/screens/games.dart';
import 'package:netflix/screens/search.dart';
import 'package:netflix/screens/downloads.dart';


class NAVBAR extends StatefulWidget {
  const NAVBAR({super.key});

  @override
  State<NAVBAR> createState() => _NAVBARState();
}

class _NAVBARState extends State<NAVBAR> {
int _currentIndex =0;
List screens = [
  HomePage(),
  SEARCH(),
  DOWNLOADS(),
  COMINGSOON(),
  GAMES(),
];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
        body: screens[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (value) {
           _currentIndex = value;
          setState(() {
           
          });
        },
        backgroundColor: Colors.black,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white.withOpacity(.60),
        selectedFontSize: 13,
        unselectedFontSize: 10,
        items: const [
          BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
          BottomNavigationBarItem(label: "Search", icon: Icon(Icons.search)),
          BottomNavigationBarItem(label: "Downloads", icon: Icon(Icons.download)),
          BottomNavigationBarItem(label: "Coming Soon", icon: Icon(Icons.add_comment_outlined)),
          BottomNavigationBarItem(label: "Games", icon: Icon(Icons.menu)),
          
        ],),
      ),
    );
  }
}