import 'package:flutter/material.dart';

class SEARCHPAGE extends StatefulWidget {
  const SEARCHPAGE({super.key});

  @override
  State<SEARCHPAGE> createState() => _SEARCHPAGEState();
}

class _SEARCHPAGEState extends State<SEARCHPAGE> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: 
    Scaffold( backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: const Icon(Icons.notifications),
        title: Center(child: Image.asset("assets/musiclogo.png", height: 50, width: 100,),),
        actions: const [Icon(Icons.settings)],
        centerTitle: true,
        
      ),
      body:  SingleChildScrollView(
        child: Column(children: [
           const SearchBar(hintText: "Search music and podcasts"),
           const SizedBox(height: 10,),
           const Chip(label: Text("Podcasts")),
          const Padding(
             padding: EdgeInsets.all(8.0),
             child: Center(child: Text("Moods & Activities", style: TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.bold),)),
           ),
          Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.pink, Colors.purple], "Love & Heartbreak"),
          ),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.yellow, Colors.purple], "Be Happy"),
          ),
          
        ]
      ),
      Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.yellow, Colors.red], "Work Out"),
          ),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.blueGrey, Colors.blue], "Chilling out & Lounging"),
          ),
          
        ]
      ),
      Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.blue, Colors.red, Colors.purple], "Travel"),
          ),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.red, Colors.green], "Party Time"),
          ),
          
        ]
      ),
      const Padding(
             padding: EdgeInsets.all(8.0),
             child: Center(child: Text("Moods & Activities", style: TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.bold))),
           ),
          Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.pink, Colors.purple], "Love & Heartbreak"),
          ),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.yellow, Colors.purple], "Be Happy"),
          ),
          
        ]
      ),
      Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.yellow, Colors.red], "Work Out"),
          ),
          customGradientContainer(context, [Colors.blueGrey, Colors.blue], "Chilling out & Lounging"),
          
        ]
      ),
      Row(
        children: [
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.blue, Colors.red, Colors.purple], "Travel"),
          ),
          Padding(
        padding: const EdgeInsets.all(8.0),
        child: customGradientContainer(context, [Colors.red, Colors.green], "Party Time"),
          ),
          
        ]
      ),
      
      
        ],),
      ),
      ));
  }
}
Container customGradientContainer(BuildContext context, List<Color> colors, String text) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.45,
    height: MediaQuery.of(context).size.height * 0.2,
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: colors),
      borderRadius: BorderRadius.circular(20.0),

    ),
    child: Center(
      child: Text(
        text,
        style: TextStyle(color: Colors.white),
      ),
    ),
  );
}