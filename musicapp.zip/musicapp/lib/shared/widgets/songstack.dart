import 'package:flutter/material.dart';

class SongStack extends StatefulWidget {
  const SongStack({Key? key, required this.imagesrc}) : super(key: key);

  final String imagesrc;

  @override
  State<SongStack> createState() => _SongStackState();
}

class _SongStackState extends State<SongStack> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 0.4,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
            child: Image.asset(widget.imagesrc, fit: BoxFit.fill),
          ),
          Positioned(
            bottom: 0,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.08,
              width: MediaQuery.of(context).size.width * 0.4,
              color: Colors.pink,
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "50 Most Played",
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
