class youtubeModel {
  late String channelTitle;
  late String id;
  late Snippet snippet;
  late ContentDetails contentDetails;
  late Statistics statistics;

  youtubeModel({
    required this.channelTitle,
    required this.id,
    required this.snippet,
    required this.contentDetails,
    required this.statistics
  });

  factory youtubeModel.extractFromJSON(Map<String, dynamic> jsonMap) {
    return youtubeModel(
      snippet: Snippet.extractFromJSON(jsonMap['snippet']),
      channelTitle: jsonMap['snippet']['channelTitle'] ?? "not avail",
      id: jsonMap['id'] ?? "not avail",
      contentDetails: ContentDetails.extractFromJSON(jsonMap['contentDetails']),
      statistics: Statistics.extractFromJSON(jsonMap['statistics']),
    );
  }
}
class Snippet {
  late String channelTitle;
  late String title;
  late String publishedAt;
  late Thumbnails thumbnails;

  Snippet({
    required this.channelTitle,
    required this.title,
    required this.thumbnails,
    required this.publishedAt,
     
  });

  factory Snippet.extractFromJSON(Map<String, dynamic> json) {
    return Snippet(
      channelTitle: json['channelTitle'] ?? "not avail",
      title: json['title'],
      thumbnails: json['thumbnails'] ?? {},
      publishedAt: json['publishedAt'] ?? "not avail"
    );
  }
}

class Thumbnails {
  late String thumbnail;

  Thumbnails({
    required this.thumbnail,
  });

  factory Thumbnails.extractFromJSON(Map<String, dynamic> map) {
    return Thumbnails(
      thumbnail: map['url'] ?? "Not avail",
    );
  }
}


class ContentDetails {
  late String duration;
  late String definition;
  late bool licensedContent;

  ContentDetails({
    required this.definition,
    required this.duration,
    required this.licensedContent,
  });

  ContentDetails.extractFromJSON(Map<String, dynamic> map) {
    definition = map["definition"] ?? "NA";
    duration = map["duration"] ?? "NA";
    licensedContent = map["licensedContent"] ?? "NA";
  }
}

class Statistics {
  late String viewCount;
  late String likeCount;
  late String commentCount;
  late String favouriteCount;

  Statistics({
    required this.commentCount,
    required this.favouriteCount,
    required this.likeCount,
    required this.viewCount,
  });

  Statistics.extractFromJSON(Map<String, dynamic> map) {
    likeCount = map["likeCount"] ?? "NA";
    commentCount = map["commentCount"] ?? "NA";
    favouriteCount = map["favouriteCount"] ?? "NA";
    viewCount = map["viewCount"] ?? "NA";
  }
}
