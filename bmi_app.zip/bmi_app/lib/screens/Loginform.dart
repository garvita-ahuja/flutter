import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LOGINFORM extends StatefulWidget {
  const LOGINFORM({super.key});

  @override
  State<LOGINFORM> createState() => _LOGINFORMState();
}

class _LOGINFORMState extends State<LOGINFORM> {
  TextEditingController textfield = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body:
        Column(children: [
        TextField(
          controller: textfield,
          obscureText: true,
          decoration: InputDecoration(
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(50))
            ),
            prefixIcon: const Icon(Icons.search),
            suffixIcon: IconButton(onPressed: (){}, icon: const Icon(Icons.clear)),
            label: const Text("Username"),
            hintText: "min 8 characters"),
            obscuringCharacter: "*",
            keyboardType: TextInputType.number,
            onChanged: (string) {
              //print(controller.text);
              print("This is the text from the textfield $string");
              },
            onEditingComplete: () {
              print("finalsubmission ${textfield.text}");
            },

          ),
           Text("HELLO FLUTTER", style: GoogleFonts.oldStandardTt(fontSize: 30)),
          //  SizedBox(
          //   height: 200,
          //   width: 200,
          //   child: Card(
          //     elevation: 20,
          //     color: const Color.fromARGB(255, 11, 137, 239),
          //     shadowColor: Colors.white,
          //     child: Center(child: Text("Garvita"),),)
          //     ),
          //     Container(
          //       height: 200,
          //       width: 200,
          //       decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.pink, Colors.purple, Colors.blue])),
          //     ),
              const Chip(label: Text("Pizza"),
              avatar: CircleAvatar(child: Text("🍕"),),
              deleteIcon: Icon(Icons.delete),
              padding: EdgeInsets.all(10),
              ),
              Container(
                color: Colors.white,
                width: double.infinity,
                height: 300,
                child: Image.asset("assets/tombraider.png",
                fit: BoxFit.fitHeight),
                
              )
        ]
              )
        )
  );
      
    
}}