import 'package:flutter/material.dart';

class ORIGINALS extends StatelessWidget {
  const ORIGINALS({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [const Text("Netflix Originals", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      Container( width: double.infinity,
      height: 500,
      child: ListView(
        padding: const EdgeInsets.all(10),
        scrollDirection: Axis.horizontal,
        children: [
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/black_mirror.jpg"),
          ),
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/carole.jpg"),
          ),
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/crown.jpg"),
          ),
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/daredevil.jpeg"),
          ),
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/stranger_things.jpg"),
          ),
          Container(
            height: 500,
            width: 400,
            child: Image.asset("assets/you.jpeg"),
          ),
        ],


      ),

    )],

    );
  }
}