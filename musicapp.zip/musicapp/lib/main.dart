

//import 'package:cadence/screens/homeScreen.dart';
import 'package:cadence/navbar.dart';
//import 'package:cadence/screens/homepage.dart';
//import 'package:cadence/screens/loadingScreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    //initialRoute: '/',
    // routes: {
    //   // '/':(context) => const LoadingScreen(),
    //   // '/home':(context) => const HomePage(),
    //   '/home2': (context) => const Home(),
    // },
    
    home: NAVBAR(),
    
  ));
}
