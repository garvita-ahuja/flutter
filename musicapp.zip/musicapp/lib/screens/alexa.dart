import 'package:flutter/material.dart';

class ALEXA extends StatefulWidget {
  const ALEXA({super.key});

  @override
  State<ALEXA> createState() => _ALEXAState();
}

class _ALEXAState extends State<ALEXA> {
  @override
  Widget build(BuildContext context) {
    return  SafeArea(child: 
    Scaffold( backgroundColor: Colors.black,
      body: 
      Column(        
        children: [const Center(child:  Text("Control music with your voice -", style: TextStyle(fontSize: 40, color: Colors.white),)),
         const Center(child: Text("just ask Alexa", style: TextStyle(fontSize: 40, color: Colors.blue),)),

        Padding(
          padding: const EdgeInsets.only(bottom:50, top: 20),
          child: Image.asset("assets/alexa_page.png", 
          height: MediaQuery.of(context).size.height*0.2,
          width: MediaQuery.of(context).size.width*0.4,),
        ),
        const Padding(
          padding:  EdgeInsets.all(10),
          child:  Center(
            child: Text("To use Alexa hands free please allow access to your device's microphone", 
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),),
          ),
        ),
         Container(height: MediaQuery.of(context).size.height*0.1, width: MediaQuery.of(context).size.width*0.8, 
         decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.blue ),
         child: const Center(child:  Text("Go to Settings", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20))), ),
         const Padding(
           padding:  EdgeInsets.only(top: 10),
           child: Center(child: Text("Cancel", style: TextStyle(color: Colors.white))),),
         
        ]

        
      ),));
  }
}