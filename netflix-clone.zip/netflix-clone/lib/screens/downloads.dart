import 'package:flutter/material.dart';

class DOWNLOADS extends StatelessWidget {
  const DOWNLOADS({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold( 
        backgroundColor: Colors.black,
        body:
        Column(
      children: [Container(
        height: MediaQuery.of(context).size.height*0.1,
        width: MediaQuery.of(context).size.width,
        child: Row(
          children: [ const Icon(Icons.info_outline, color: Colors.white,),
             const Text("Smart Downloads", style: TextStyle(color: Colors.white, fontSize: 20)),
             GestureDetector(child: const Text("ON", style: TextStyle(color: Colors.blue)), onTap: () {               
             },),
        ],
        ),
      ),
      SizedBox(height: MediaQuery.of(context).size.height*0.1),
       Container(

        height: MediaQuery.of(context).size.height*0.5,
        width: MediaQuery.of(context).size.width*0.7,
         child: const Column( mainAxisAlignment: MainAxisAlignment.center,
         children: [Icon(Icons.download_for_offline_sharp, size: 200, color: Colors.grey,),
         Text("Movies and TV shows that you download appear here.", style: TextStyle(fontSize: 20, color: Colors.grey),)]),
       ),
      SizedBox(height: MediaQuery.of(context).size.height*0.15),

       Padding(
               padding: const EdgeInsets.only(left: 20, right: 20),
               child: Container(padding: const EdgeInsets.only(left: 10, right: 10, top: 5, bottom: 5),
                color: Colors.white, 
               child: const Text("Find Something to Download", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)) ),
             ),


      ])));
  }
}