import 'package:cadence/screens/alexa.dart';
import 'package:cadence/screens/homepage.dart';
import 'package:cadence/screens/personal.dart';
import 'package:cadence/screens/searchpage.dart';
import 'package:flutter/material.dart';

class NAVBAR extends StatefulWidget {
  const NAVBAR({Key? key}) : super(key: key);

  @override
  State<NAVBAR> createState() => _NAVBARState();
}

class _NAVBARState extends State<NAVBAR> {
  int currentIndex = 0;
  List screens = [Home(), SEARCHPAGE(), PERSONAL(), ALEXA()];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
        body: screens[currentIndex],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: currentIndex,
          type: BottomNavigationBarType.fixed,
          onTap: (value) {
            setState(() {
              currentIndex = value;
            });
          },
          backgroundColor: Colors.blueGrey,
          unselectedItemColor: Colors.lightBlue,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle_outlined), label: 'Personal'),
            BottomNavigationBarItem(icon: Icon(Icons.voice_chat), label: 'Alexa'),
          ],
        ),
      ),
    );
  }
}
