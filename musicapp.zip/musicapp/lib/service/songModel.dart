class SongModel{
  late String artistName;
  late String trackName;
  late String artworkUrl100;
  late String previewUrl;
  bool isPlaying =false;
  SongModel(
    {required this.artistName,
    required this.trackName,
    required this.artworkUrl100,
    required this.previewUrl,      
    }
  );
  SongModel.fromJSON(Map <String, dynamic> jsonMap){
    artistName = jsonMap['artistName'] ?? "not avail";
    trackName = jsonMap['trackName'] ?? "not avail";
    artworkUrl100 = jsonMap['artworkUrl100'] ?? "not avail";
    previewUrl = jsonMap['previewUrl'] ?? "not avail";

  }
}