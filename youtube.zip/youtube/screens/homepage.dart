import 'package:flutter/material.dart';
import 'package:youtubeboi/screens/videopage.dart';
import 'package:youtubeboi/services/ytclient.dart';
import 'package:youtubeboi/services/ytmodel.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key); 

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
   youtubeClient ytClient = youtubeClient(); 
   late Future <List <youtubeModel>> vidList;

 Future<List<youtubeModel>> getVideos() async {
  Map<String, dynamic>? videoMap = await ytClient.getVideosFromYoutube();
    
  List<dynamic> vList = videoMap["items"];
  List<youtubeModel> vidList = genericToSpecificObject(vList);
  return vidList;
}


  List<youtubeModel> genericToSpecificObject(List<dynamic> list) {
    List<youtubeModel> vidList = list.map((singleObject) {
      return youtubeModel.extractFromJSON(singleObject);
    }).toList();
    return vidList;
  }
@override
  void initState() {
    // TODO: implement initState
    vidList = getVideos();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text("YOUTUBE", style: TextStyle(color: Colors.black),),
          centerTitle: true,
          backgroundColor: Colors.white,
        ),
        body: Container(
          color: Colors.white,
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: FutureBuilder<List<youtubeModel>>(
  future: getVideos(),
  builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const Center(child: CircularProgressIndicator());
    } else if (snapshot.hasError) {
      return Center(
        child: Text(snapshot.error.toString()),
      );
    } else if (snapshot.hasData) {
      return ListView.builder(
        itemCount: snapshot.data!.length,
        itemBuilder: (context, index) {
          return SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Card(
              child: Column(
                children: [
                  Image.network(snapshot.data![index].snippet.thumbnails.thumbnail),
                  Text(
                    snapshot.data![index].snippet.title,
                    style: const TextStyle(color: Colors.black, fontSize: 20),
                  ),
                  SizedBox(height: 5),
                  Text(
                    snapshot.data![index].snippet.channelTitle,
                    style: const TextStyle(color: Colors.black, fontSize: 20),
                    ),
                    GestureDetector(onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(playList: snapshot.data!, currentIndex: index,)));
                    },)

                ],
                
              ),
            ),
          );
        },
      );
    } else {
      return const Center(child: Text("No data available"));
    }
  },
)
)));}}
