import 'package:bmiapp/screens/Loginform.dart';
import 'package:bmiapp/screens/firstPage.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    theme: ThemeData.dark(),
    debugShowCheckedModeBanner: false,
    home: LOGINFORM(),

  )
  );

}