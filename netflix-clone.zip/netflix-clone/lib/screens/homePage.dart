import 'package:flutter/material.dart';
import 'package:netflix/navbar.dart';

import 'package:netflix/shared/widgets/mylist.dart';
import 'package:netflix/shared/widgets/nf_originals.dart';
import 'package:netflix/shared/widgets/nf_stack.dart';
import 'package:netflix/shared/widgets/preview.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}


class _HomePageState extends State<HomePage> {
 
  @override
  Widget build(BuildContext context) {
    return  SafeArea(
      child: Scaffold( 
extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          leading: Image.asset("assets/nf.png"),
          actions: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {},
                child: const Text(
                  "TV Shows",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {
                  print("MOV is called");
                },
                child: const Text(
                  "Movies",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {},
                child: const Text(
                  "My List",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            )],
        ),
           
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
            color: Colors.black,
            width: double.infinity,
        
            child: const Column(children: [NFSTACK(), PREVIEW(), MYLIST(), ORIGINALS(),] )
        )]),
        ),
    
    ));
  }
}