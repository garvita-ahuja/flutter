import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [const Text("Previews", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      SizedBox( width: double.infinity,
      height: 150,
        child: ListView(
          padding: const EdgeInsets.all(10),
          scrollDirection: Axis.horizontal,
          children: [CircleAvatar(
            radius: 55,
            backgroundImage: AssetImage("assets/dogs.jpg"),
          ),
          const CircleAvatar(
            radius: 55,
            backgroundImage: AssetImage("assets/witcher.jpg"),
          ),
          const CircleAvatar(
            radius: 55,
            backgroundImage: AssetImage("assets/umbrella_academy.jpg"),
          ),
          const CircleAvatar(
            radius: 55,
            backgroundImage: AssetImage("assets/stranger_things.jpg"),
          ),
          const CircleAvatar(
            radius: 55,
            backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
          ),
          const CircleAvatar(
            radius: 55,
            backgroundImage:  AssetImage("assets/sintel.jpg"),
          )],
        ),
      )
      ],
    );
  }
}