import 'package:flutter/material.dart';
import 'package:netflix/navbar.dart';

void main() {
  runApp(const MaterialApp(
    home: NAVBAR(),
  ));
}
