import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:youtubeboi/services/ytmodel.dart';

// ignore: must_be_immutable
class VideoPage extends StatefulWidget {
  late List<youtubeModel> playList;
  late int currentIndex;

  VideoPage({ required this.playList, required this.currentIndex,super.key});

  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late YoutubePlayerController ytcontroller;
  @override
  void initState() {
    // TODO: implement initState
    
    ytcontroller = YoutubePlayerController(
      initialVideoId: widget.playList[widget.currentIndex].id,
      flags: const YoutubePlayerFlags(
        autoPlay: true,)

    );
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Container(
        padding: EdgeInsets.all(10),
      
      child: Column(
        children: [
          YoutubePlayer(controller: ytcontroller,
          showVideoProgressIndicator: true,
          onReady: () {
            print("video loaded");
          },
          bottomActions: [
            CurrentPosition(),
            ProgressBar(
              isExpanded: true,
              colors: ProgressBarColors(
                playedColor: Colors.red,
                handleColor: Colors.red,
                backgroundColor: Colors.white,
              ),
            ),
            RemainingDuration(),
            PlaybackSpeedButton(),
            FullScreenButton()
          ],
          )
        ],
      )
    )));
  }
}