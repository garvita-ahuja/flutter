import 'package:flutter/material.dart';

class MYLIST extends StatelessWidget {
  const MYLIST({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [const Text("Previews", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      SizedBox( width: double.infinity,
      height: 300,
      child: ListView(
        padding: const EdgeInsets.all(10),
        scrollDirection: Axis.horizontal,
        children: [
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/sabrina.jpeg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/riverdale.jpeg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/lucifer.jpeg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/daredevil.jpeg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/witcher.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("assets/you.jpeg"),
          ),
        ],


      ),

    )],

    );
  }
}