class Note{
  final String noteId;
  final String title;
  final String body;
  Note({required this.title, required this.body, required this.noteId});
}