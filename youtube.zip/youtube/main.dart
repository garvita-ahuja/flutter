import 'package:flutter/material.dart';
import 'package:youtubeboi/screens/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
